"use client";
import { CartContext } from "@/Context/cartContext";
import { signOut, useSession } from "next-auth/react";
import Link from "next/link";
import React, { useContext } from "react";
import { useState } from "react";
import { MoreHorizontalIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import { Field, FieldGroup, FieldLabel } from "@/components/ui/field";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function Navbar() {
  const { data: session, status } = useSession();
  console.log("NAVBER")

  const [showNewDialog, setShowNewDialog] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);

  function logOut() {
    signOut({ redirect: false });
  }
  const context = useContext(CartContext);

  if (!context) {
    throw new Error("Context undefined");
  }

  const { cartNumItems } = context;
  return (
    <nav className="bg-emerald-600 text-white fixed top-0 w-full z-5">
      <div className="container w-full lg:w-[80%] mx-auto p-4 flex flex-col gap-4 lg:flex-row lg:justify-between justify-between items-center">
        <div>
          <ul className="flex gap-2 lg:gap-6 items-center">
            <li className="font-bold flex lg:text-xl">
              <Link href="/">
                <i className="fa-solid fa-cart-shopping"></i>Freshcart
              </Link>
            </li>
            <li>
              <Link href="/">Home</Link>
            </li>
            {session && (
              <li>
                <Link className="relative" href="/cart">
                  Cart
                  <span className="absolute top-[-10px] text-sm bg-yellow-200 size-5 text-center text-black rounded-full">
                    {cartNumItems}
                  </span>
                </Link>
              </li>
            )}
            <li>
              <Link href="/products">Products</Link>
            </li>
            <li>
              <Link href="/categories">Categories</Link>
            </li>
            <li>
              <Link href="/brands">Brands</Link>
            </li>
            <li>
              <Link href="/wishlist">Wishlist</Link>
            </li>
          </ul>
        </div>
        <div>
          <ul className="flex gap-8">
            <li>
              <i className="fab fa-facebook"></i>
            </li>
            <li>
              <i className="fab fa-twitter"></i>
            </li>
            <li>
              <i className="fab fa-instagram"></i>
            </li>
            <li>
              <i className="fab fa-tiktok"></i>
            </li>
            <li>
              <i className="fab fa-linkedin"></i>
            </li>
            {!session && (
              <li>
                {" "}
                <Link href="/register">Register</Link>
              </li>
            )}
            {!session && (
              <li>
                {" "}
                <Link href="/login">Login</Link>
              </li>
            )}
            <DropdownMenu modal={false}>
              <DropdownMenuTrigger asChild>
                {session && (
                  <li className="cursor-pointer">Hi {session.user.name}</li>
                )}
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-40 z-50" align="end">
                <DropdownMenuLabel>Profile Actions</DropdownMenuLabel>
                <DropdownMenuGroup>
                  <DropdownMenuItem onSelect={() => setShowNewDialog(true)}>
                    View Orders
                  </DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => setShowShareDialog(true)}>
                    Change Password
                  </DropdownMenuItem>
                  <DropdownMenuItem disabled>Download</DropdownMenuItem>
                </DropdownMenuGroup>
              </DropdownMenuContent>
            </DropdownMenu>

            {session && (
              <li>
                <span onClick={logOut} className="cursor-pointer">
                  Signout
                </span>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
}
