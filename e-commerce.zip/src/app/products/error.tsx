"use client"
import React from 'react'

export default function error() {
  return (
    <div>Trouble getting products</div>
  )
}
