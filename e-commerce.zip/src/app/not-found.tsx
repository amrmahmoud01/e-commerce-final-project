import React from "react";

export default function notfound() {
  return <h1 className="mt-50 text-center">Not Found peepeeepoopoo</h1>;
}
